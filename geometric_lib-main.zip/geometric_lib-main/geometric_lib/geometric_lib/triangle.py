def area(a, b, c):
    return (a + b + c) / 2


def perimeter(a, b, c):
    return a + b + c
